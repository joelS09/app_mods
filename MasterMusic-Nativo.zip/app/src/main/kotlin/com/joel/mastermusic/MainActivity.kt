package com.joel.mastermusic

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.database.ContentObserver
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.MediaStore
import android.provider.Settings
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

fun audioPerm() = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
fun hasPerm(c: Context) = ContextCompat.checkSelfPermission(c, audioPerm()) == PackageManager.PERMISSION_GRANTED
fun ignoringBattery(c: Context) = (c.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(c.packageName)
fun fmt(ms: Long): String { val s = ms / 1000; return "${s / 60}:${(s % 60).toString().padStart(2, '0')}" }

@Composable
fun App() {
    val c = LocalContext.current
    var accent by remember { mutableStateOf(Store.accent(c)) }
    val on = if (Color(accent).luminance() > 0.5f) Color.Black else Color.White
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(accent), onPrimary = on, background = Color(0xFF0B0D10), surface = Color(0xFF14181D),
            onBackground = Color.White, onSurface = Color.White, surfaceVariant = Color(0xFF1E242B)
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Main(accent) { accent = it; Store.setAccent(c, it) }
        }
    }
}

@Composable
fun Art(id: Long?, album: Long, size: Dp, px: Int = 256, mod: Modifier = Modifier) {
    val c = LocalContext.current
    val bmp by produceState<Bitmap?>(null, id) {
        value = if (id == null) null else withContext(Dispatchers.IO) { Covers.get(c, id, album, px) }
    }
    Box(
        mod.size(size).clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center
    ) {
        val b = bmp
        if (b != null) Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Icon(Icons.Filled.MusicNote, null, tint = MaterialTheme.colorScheme.primary)
    }
}

@Composable
fun SongRow(s: Song, cur: Boolean, onClick: () -> Unit, trailing: @Composable () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Art(s.id, s.album, 48.dp, 128)
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(s.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold,
                color = if (cur) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
            Text(s.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 13.sp, color = Color.Gray)
        }
        trailing()
    }
}

@Composable
fun Main(accent: Int, setAccent: (Int) -> Unit) {
    val c = LocalContext.current
    val scope = rememberCoroutineScope()
    var songs by remember { mutableStateOf(listOf<Song>()) }
    var favs by remember { mutableStateOf(Store.favs(c)) }
    var lists by remember { mutableStateOf(Store.lists(c)) }
    var granted by remember { mutableStateOf(hasPerm(c)) }
    var tab by remember { mutableStateOf(0) }
    var full by remember { mutableStateOf(false) }
    var openList by remember { mutableStateOf<String?>(null) }
    var addTo by remember { mutableStateOf<Song?>(null) }
    var newList by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var askBattery by remember { mutableStateOf(!ignoringBattery(c)) }

    fun rescan() { if (hasPerm(c)) scope.launch { songs = withContext(Dispatchers.IO) { scan(c) } } }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { granted = hasPerm(c); rescan() }
    LaunchedEffect(Unit) {
        val p = mutableListOf(audioPerm())
        if (Build.VERSION.SDK_INT >= 33) p += Manifest.permission.POST_NOTIFICATIONS
        perm.launch(p.toTypedArray()); rescan()
    }
    DisposableEffect(Unit) {
        val o = object : ContentObserver(Handler(Looper.getMainLooper())) { override fun onChange(selfChange: Boolean) { rescan() } }
        c.contentResolver.registerContentObserver(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, true, o)
        onDispose { c.contentResolver.unregisterContentObserver(o) }
    }

    var mc by remember { mutableStateOf<MediaController?>(null) }
    var cur by remember { mutableStateOf<Long?>(null) }
    var playing by remember { mutableStateOf(false) }
    var rep by remember { mutableStateOf(0) }
    var shuf by remember { mutableStateOf(false) }
    var pos by remember { mutableStateOf(0L) }
    var dur by remember { mutableStateOf(0L) }
    DisposableEffect(Unit) {
        val f = MediaController.Builder(c, SessionToken(c, ComponentName(c, PlayerService::class.java))).buildAsync()
        fun sync(p: Player) {
            cur = p.currentMediaItem?.mediaId?.toLongOrNull(); playing = p.isPlaying
            rep = p.repeatMode; shuf = p.shuffleModeEnabled; dur = maxOf(0L, p.duration)
        }
        val l = object : Player.Listener { override fun onEvents(p: Player, e: Player.Events) { sync(p) } }
        f.addListener({ try { val m = f.get(); mc = m; m.addListener(l); sync(m) } catch (_: Exception) {} }, ContextCompat.getMainExecutor(c))
        onDispose { MediaController.releaseFuture(f) }
    }
    LaunchedEffect(mc) { while (true) { pos = mc?.currentPosition ?: 0L; delay(500) } }

    fun playList(l: List<Song>, i: Int) { val m = mc ?: return; m.setMediaItems(l.map { item(it) }, i, 0L); m.prepare(); m.play() }
    fun toggleFav(id: Long) {
        favs = if (id in favs) favs - id else favs + id
        Store.setFavs(c, favs); mc?.let { MusicWidget.push(c, it) }
    }
    fun addToList(name: String, id: Long) {
        lists = lists + (name to ((lists[name] ?: emptyList()) + id).distinct()); Store.setLists(c, lists)
    }
    val byId = songs.associateBy { it.id }
    val curSong = cur?.let { byId[it] }

    @Composable fun heart(s: Song) = IconButton({ toggleFav(s.id) }) {
        Icon(if (s.id in favs) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, null, tint = MaterialTheme.colorScheme.primary)
    }

    Box(Modifier.fillMaxSize()) {
        Scaffold(
            containerColor = Color.Transparent,
            bottomBar = {
                Column {
                    if (curSong != null) {
                        Row(
                            Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).clickable { full = true }.padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Art(curSong.id, curSong.album, 44.dp, 128)
                            Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                                Text(curSong.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                                Text(curSong.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp, color = Color.Gray)
                            }
                            IconButton({ mc?.let { if (it.isPlaying) it.pause() else it.play() } }) {
                                Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, null, tint = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                    NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                        listOf("Canciones" to Icons.Filled.MusicNote, "Favoritos" to Icons.Filled.Favorite,
                            "Listas" to Icons.Filled.QueueMusic, "Ajustes" to Icons.Filled.Settings).forEachIndexed { n, (t, ic) ->
                            NavigationBarItem(selected = tab == n, onClick = { tab = n; openList = null },
                                icon = { Icon(ic, null) }, label = { Text(t, fontSize = 11.sp) })
                        }
                    }
                }
            }
        ) { pad ->
            Column(Modifier.padding(pad).fillMaxSize()) {
                if (!granted && tab != 3) {
                    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Permite el acceso a tu música para listar tus canciones automáticamente.", fontSize = 16.sp)
                        Spacer(Modifier.height(16.dp))
                        Button({ perm.launch(arrayOf(audioPerm())) }) { Text("Dar permiso") }
                    }
                } else when (tab) {
                    0 -> {
                        OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth().padding(12.dp), singleLine = true,
                            placeholder = { Text("Buscar (${songs.size} canciones)") })
                        val shown = songs.filter { query.isBlank() || it.title.contains(query, true) || it.artist.contains(query, true) }
                        LazyColumn(Modifier.weight(1f)) {
                            items(shown, key = { it.id }) { s ->
                                SongRow(s, s.id == cur, { playList(shown, shown.indexOf(s)) }) {
                                    heart(s); IconButton({ addTo = s }) { Icon(Icons.Filled.Add, null) }
                                }
                            }
                        }
                    }
                    1 -> {
                        val fl = songs.filter { it.id in favs }
                        Header("Favoritos", if (fl.isEmpty()) null else ({ playList(fl, 0) }))
                        if (fl.isEmpty()) Text("Toca el corazón en una canción para guardarla aquí.", Modifier.padding(16.dp), color = Color.Gray)
                        LazyColumn { items(fl, key = { it.id }) { s -> SongRow(s, s.id == cur, { playList(fl, fl.indexOf(s)) }) { heart(s) } } }
                    }
                    2 -> {
                        val name = openList
                        if (name == null) {
                            Header("Listas de reproducción", null)
                            Button({ newList = true }, Modifier.padding(horizontal = 16.dp)) { Icon(Icons.Filled.Add, null); Text(" Nueva lista") }
                            LazyColumn {
                                items(lists.keys.toList()) { n ->
                                    ListItem(headlineContent = { Text(n, fontWeight = FontWeight.SemiBold) },
                                        supportingContent = { Text("${lists[n]!!.count { it in byId }} canciones") },
                                        leadingContent = { Icon(Icons.Filled.QueueMusic, null, tint = MaterialTheme.colorScheme.primary) },
                                        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                                        modifier = Modifier.clickable { openList = n })
                                }
                            }
                        } else {
                            BackHandler { openList = null }
                            val ls = (lists[name] ?: emptyList()).mapNotNull { byId[it] }
                            Row(Modifier.padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                IconButton({ openList = null }) { Icon(Icons.Filled.KeyboardArrowDown, null) }
                                Text(name, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                if (ls.isNotEmpty()) IconButton({ playList(ls, 0) }) { Icon(Icons.Filled.PlayArrow, null, tint = MaterialTheme.colorScheme.primary) }
                                IconButton({ lists = lists - name; Store.setLists(c, lists); openList = null }) { Icon(Icons.Filled.Delete, null) }
                            }
                            LazyColumn {
                                items(ls, key = { it.id }) { s ->
                                    SongRow(s, s.id == cur, { playList(ls, ls.indexOf(s)) }) {
                                        IconButton({ lists = lists + (name to (lists[name]!! - s.id)); Store.setLists(c, lists) }) { Icon(Icons.Filled.Delete, null) }
                                    }
                                }
                            }
                        }
                    }
                    else -> Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        Text("Ajustes", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        Text("Color de la interfaz")
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            listOf(0xFF39FF6A, 0xFF00D4FF, 0xFF7C5CFF, 0xFFFF4D8D, 0xFFFF9F1C, 0xFFFF5252).forEach { col ->
                                Box(Modifier.size(38.dp).clip(CircleShape).background(Color(col)).clickable { setAccent(col.toInt()) })
                            }
                        }
                        Button({ c.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + c.packageName))) }) {
                            Text("Permitir segundo plano (batería)")
                        }
                        Button({ rescan() }) { Text("Reescanear música ahora") }
                        Text("Widget: mantén presionada la pantalla de inicio → Widgets → Master Music.", color = Color.Gray, fontSize = 13.sp)
                        Text("By Joel", color = Color.Gray, fontSize = 13.sp)
                    }
                }
            }
        }

        if (full) {
            BackHandler { full = false }
            Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                IconButton({ full = false }, Modifier.align(Alignment.Start)) { Icon(Icons.Filled.KeyboardArrowDown, null) }
                Art(curSong?.id, curSong?.album ?: 0L, 300.dp, 600)
                Spacer(Modifier.height(20.dp))
                Text(curSong?.title ?: "", fontSize = 21.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(curSong?.artist ?: "", color = Color.Gray)
                Slider(pos.toFloat().coerceIn(0f, maxOf(1L, dur).toFloat()), { pos = it.toLong() },
                    onValueChangeFinished = { mc?.seekTo(pos) }, valueRange = 0f..maxOf(1L, dur).toFloat())
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(fmt(pos), fontSize = 12.sp, color = Color.Gray); Text(fmt(dur), fontSize = 12.sp, color = Color.Gray)
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    IconButton({ mc?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled } }) {
                        Icon(Icons.Filled.Shuffle, null, tint = if (shuf) MaterialTheme.colorScheme.primary else Color.Gray)
                    }
                    IconButton({ mc?.seekToPreviousMediaItem() }) { Icon(Icons.Filled.SkipPrevious, null, Modifier.size(36.dp)) }
                    FilledIconButton({ mc?.let { if (it.isPlaying) it.pause() else it.play() } }, Modifier.size(70.dp)) {
                        Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, null, Modifier.size(38.dp))
                    }
                    IconButton({ mc?.seekToNextMediaItem() }) { Icon(Icons.Filled.SkipNext, null, Modifier.size(36.dp)) }
                    IconButton({
                        mc?.let { it.repeatMode = when (it.repeatMode) { Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL; Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE; else -> Player.REPEAT_MODE_OFF } }
                    }) {
                        Icon(if (rep == Player.REPEAT_MODE_ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat, null,
                            tint = if (rep == Player.REPEAT_MODE_OFF) Color.Gray else MaterialTheme.colorScheme.primary)
                    }
                }
                Text(when (rep) { Player.REPEAT_MODE_ONE -> "Repetir una canción"; Player.REPEAT_MODE_ALL -> "Repetir lista"; else -> "Sin repetir" }, fontSize = 12.sp, color = Color.Gray)
                if (curSong != null) Row {
                    heart(curSong); IconButton({ addTo = curSong }) { Icon(Icons.Filled.Add, null) }
                }
            }
        }
    }

    addTo?.let { s ->
        AlertDialog(onDismissRequest = { addTo = null }, confirmButton = { TextButton({ addTo = null }) { Text("Cerrar") } },
            title = { Text("Agregar a lista") }, text = {
                Column {
                    lists.keys.forEach { n -> TextButton({ addToList(n, s.id); addTo = null }) { Text(n) } }
                    TextButton({ newList = true }) { Text("＋ Nueva lista") }
                }
            })
    }
    if (newList) {
        var name by remember { mutableStateOf("") }
        AlertDialog(onDismissRequest = { newList = false },
            confirmButton = { TextButton({
                val n = name.trim()
                if (n.isNotEmpty()) { lists = lists + (n to (lists[n] ?: emptyList())); Store.setLists(c, lists); addTo?.let { addToList(n, it.id) }; addTo = null }
                newList = false }) { Text("Crear") } },
            dismissButton = { TextButton({ newList = false }) { Text("Cancelar") } },
            title = { Text("Nueva lista") }, text = { OutlinedTextField(name, { name = it }, singleLine = true) })
    }
    if (askBattery && granted) {
        AlertDialog(onDismissRequest = { askBattery = false },
            title = { Text("Reproducir en segundo plano") },
            text = { Text("Para que la música no se corte con la pantalla apagada, permite que Master Music ignore la optimización de batería.") },
            confirmButton = { TextButton({
                askBattery = false
                c.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + c.packageName)))
            }) { Text("Permitir") } },
            dismissButton = { TextButton({ askBattery = false }) { Text("Ahora no") } })
    }
}

@Composable
fun Header(t: String, play: (() -> Unit)?) {
    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(t, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        if (play != null) IconButton(play) { Icon(Icons.Filled.PlayArrow, null, tint = MaterialTheme.colorScheme.primary) }
    }
}
