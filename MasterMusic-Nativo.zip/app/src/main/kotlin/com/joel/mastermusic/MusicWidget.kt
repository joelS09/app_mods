package com.joel.mastermusic

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import androidx.core.content.ContextCompat
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken

/** Widget de pantalla de inicio: portada, título y botones anterior / play / siguiente / favorito. */
class MusicWidget : AppWidgetProvider() {

    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        draw(c, "Master Music", "Toca para abrir", false, false, null)
    }

    override fun onReceive(c: Context, i: Intent) {
        super.onReceive(c, i)
        val a = i.action ?: return
        if (!a.startsWith("mm.")) return
        val pending = goAsync()
        val f = MediaController.Builder(c, SessionToken(c, ComponentName(c, PlayerService::class.java))).buildAsync()
        f.addListener({
            try {
                val mc = f.get()
                when (a) {
                    "mm.play" -> if (mc.isPlaying) mc.pause() else mc.play()
                    "mm.next" -> mc.seekToNextMediaItem()
                    "mm.prev" -> mc.seekToPreviousMediaItem()
                    "mm.fav" -> mc.currentMediaItem?.mediaId?.toLongOrNull()?.let { id ->
                        val s = Store.favs(c)
                        Store.setFavs(c, if (id in s) s - id else s + id)
                    }
                }
                push(c, mc)
            } catch (_: Exception) {
            }
            MediaController.releaseFuture(f)
            pending.finish()
        }, ContextCompat.getMainExecutor(c))
    }

    companion object {
        fun push(c: Context, p: Player) {
            val it = p.currentMediaItem
            val id = it?.mediaId?.toLongOrNull()
            val md = it?.mediaMetadata
            draw(
                c, md?.title?.toString() ?: "Master Music", md?.artist?.toString() ?: "Toca para abrir",
                p.isPlaying, id != null && id in Store.favs(c), it
            )
        }

        private fun pi(c: Context, action: String) = PendingIntent.getBroadcast(
            c, action.hashCode(), Intent(c, MusicWidget::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        fun draw(c: Context, title: String, artist: String, playing: Boolean, fav: Boolean, item: androidx.media3.common.MediaItem?) {
            val m = AppWidgetManager.getInstance(c)
            val ids = m.getAppWidgetIds(ComponentName(c, MusicWidget::class.java))
            if (ids.isEmpty()) return
            val v = RemoteViews(c.packageName, R.layout.widget)
            v.setTextViewText(R.id.wt, title)
            v.setTextViewText(R.id.wa, artist)
            v.setImageViewResource(R.id.wplay, if (playing) R.drawable.ic_pause else R.drawable.ic_play)
            v.setImageViewResource(R.id.wfav, if (fav) R.drawable.ic_fav else R.drawable.ic_fav_off)
            val id = item?.mediaId?.toLongOrNull()
            if (id != null) {
                val album = item.mediaMetadata.extras?.getLong("album") ?: 0L
                val bmp = Covers.get(c, id, album, 200)
                if (bmp != null) v.setImageViewBitmap(R.id.wc, bmp) else v.setImageViewResource(R.id.wc, R.mipmap.ic_launcher)
            }
            v.setOnClickPendingIntent(R.id.wplay, pi(c, "mm.play"))
            v.setOnClickPendingIntent(R.id.wnext, pi(c, "mm.next"))
            v.setOnClickPendingIntent(R.id.wprev, pi(c, "mm.prev"))
            v.setOnClickPendingIntent(R.id.wfav, pi(c, "mm.fav"))
            val open = PendingIntent.getActivity(
                c, 0, Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            v.setOnClickPendingIntent(R.id.wc, open)
            v.setOnClickPendingIntent(R.id.wt, open)
            m.updateAppWidget(ids, v)
        }
    }
}
