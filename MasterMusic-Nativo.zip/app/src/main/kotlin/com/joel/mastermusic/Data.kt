package com.joel.mastermusic

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import org.json.JSONArray
import org.json.JSONObject

data class Song(val id: Long, val title: String, val artist: String, val album: Long, val dur: Long) {
    val uri: Uri get() = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
}

/** Escanea toda la música del teléfono (MediaStore) sin agregar nada a mano. */
fun scan(c: Context): List<Song> {
    val out = mutableListOf<Song>()
    val cols = arrayOf(
        MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST,
        MediaStore.Audio.Media.ALBUM_ID, MediaStore.Audio.Media.DURATION
    )
    val sel = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} > 30000"
    c.contentResolver.query(
        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, cols, sel, null,
        "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE"
    )?.use { cu ->
        while (cu.moveToNext()) {
            val artist = cu.getString(2)
            out += Song(
                cu.getLong(0), cu.getString(1) ?: "Sin título",
                if (artist == null || artist == "<unknown>") "Artista desconocido" else artist,
                cu.getLong(3), cu.getLong(4)
            )
        }
    }
    return out
}

object Covers {
    private val cache = LruCache<String, Bitmap>(80)
    fun get(c: Context, id: Long, album: Long, px: Int): Bitmap? {
        val key = "$id:$px"
        cache.get(key)?.let { return it }
        val b: Bitmap? = try {
            if (Build.VERSION.SDK_INT >= 29) {
                c.contentResolver.loadThumbnail(ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id), Size(px, px), null)
            } else {
                c.contentResolver.openInputStream(ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), album))
                    ?.use { BitmapFactory.decodeStream(it) }
            }
        } catch (e: Exception) { null }
        if (b != null) cache.put(key, b)
        return b
    }
}

fun item(s: Song): MediaItem = MediaItem.Builder()
    .setMediaId(s.id.toString())
    .setUri(s.uri)
    .setMediaMetadata(
        MediaMetadata.Builder()
            .setTitle(s.title).setArtist(s.artist)
            .setArtworkUri(Uri.parse("content://media/external/audio/albumart/${s.album}"))
            .setExtras(Bundle().apply { putLong("album", s.album) })
            .build()
    ).build()

object Store {
    private fun sp(c: Context) = c.applicationContext.getSharedPreferences("mm", 0)
    fun favs(c: Context): Set<Long> = sp(c).getString("favs", "")!!.split(",").mapNotNull { it.toLongOrNull() }.toSet()
    fun setFavs(c: Context, s: Set<Long>) { sp(c).edit().putString("favs", s.joinToString(",")).apply() }
    fun lists(c: Context): Map<String, List<Long>> {
        val o = JSONObject(sp(c).getString("lists", "{}")!!)
        return o.keys().asSequence().associateWith { k ->
            val a = o.getJSONArray(k); (0 until a.length()).map { a.getLong(it) }
        }
    }
    fun setLists(c: Context, m: Map<String, List<Long>>) {
        val o = JSONObject(); m.forEach { (k, v) -> o.put(k, JSONArray(v)) }
        sp(c).edit().putString("lists", o.toString()).apply()
    }
    fun accent(c: Context): Int = sp(c).getInt("accent", 0xFF39FF6A.toInt())
    fun setAccent(c: Context, v: Int) { sp(c).edit().putInt("accent", v).apply() }
}
